<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Blog;
use App\Models\BlogComments;

class FrontEndController extends Controller
{
    public function index(){
        $blogs= Blog::limit(5)->orderBy('created_at','desc')->get();
        return view('home')->with('blogs',$blogs);
    }

    public function readBlog($id){
        $data['blog']=Blog::find($id);
        $data['blog_comments']=BlogComments::where('blog_id',$id)->get()->toArray();
        return view('read-blog')->with('data',$data);
 
    }

    public function addComment(Request $request){

// dd($request);

        $blogComments =new BlogComments;
        $blogComments->name=$request->input('name');
        $blogComments->comment=$request->input('comment');
        $blogComments->blog_id=$request->input('blog_id');
        $blogComments->save();
        $lastInsertId=$blogComments->id;
        return true;
        
    }

}
