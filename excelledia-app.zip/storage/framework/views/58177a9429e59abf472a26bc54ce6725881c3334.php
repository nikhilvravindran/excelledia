<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial;
            padding: 20px;
            background: #f1f1f1;
        }


        .fakeimg {
            background-color: #aaa;
            width: 100%;
            padding: 20px;
        }

        .card {
            background-color: white;
            padding: 20px;
            margin-top: 20px;
        }

        .row:after {
            content: "";
            display: table;
            clear: both;
        }

        .comment_form {
            display: none;
        }

    </style>
</head>

<body>



    <div class="row">
        <?php if(!empty($data['blog'])): ?>
            <div class="card">
                <h2> <?php echo e($data['blog']->title); ?></h2>
                <h5>By <?php echo e($data['blog']->author); ?>,Posted on <?php echo e(date('d-m-Y', strtotime($data['blog']->created_at))); ?>

                </h5>
                <p><?php echo e($data['blog']->description); ?></p>

                <?php if(!empty($data['blog_comments'])): ?>
                    <div class="show_comments">
                        <h3>Comments</h3>
                        <?php $__currentLoopData = $data['blog_comments']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card_comment">

                                <h4> <?php echo e($comm['name']); ?></h4>
                                <p><?php echo e($comm['comment']); ?></p>
                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>


            </div>


        <?php endif; ?>


        <button type="button" class="addcomment">Add Comment</button>
        <div class="comment_form">
            <form action="#" id="comment-form">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label class="col-sm-2 col-sm-2 control-label">Name</label>
                    <div class="col-sm-10">
                        <input type="text" name="name" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 col-sm-2 control-label">Description</label>
                    <div class="col-sm-10">
                        <textarea rows="5" cols="20" class="form-control" name="comment"></textarea>
                    </div>
                </div>
                <input type="hidden" name="blog_id" value="<?php echo e($data['blog']->id); ?>">
                <button type="submit" class="btn btn-success btnSubmit">Post</button>
                <button type="button" class="btn btn-success btnClose">Close</button>
            </form>
        </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script>
        $(".addcomment").click(function() {
            $(".comment_form").slideToggle("slow");
        });
        $(".btnClose").click(function() {
            $(".comment_form").slideToggle("hide");
        })

        $("#comment-form").submit(function(e) {
            e.preventDefault();
            $.ajax({
                type: 'POST',
                url: "<?php echo e(route('add-comment')); ?>",
                data: $("#comment-form").serialize(),
                success: function(msg) {
                    $("#comment-form")[0].reset();
                    window.location.reload();
                }
            })
        });
    </script>
</body>

</html>
<?php /**PATH E:\xampp\htdocs\excelledia-app\resources\views/read-blog.blade.php ENDPATH**/ ?>