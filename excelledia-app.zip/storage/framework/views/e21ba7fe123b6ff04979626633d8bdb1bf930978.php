<!DOCTYPE html>
 <html>
 <head>
 	<meta charset="utf-8">
 	<title></title>
 	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
 </head>
 <body>
 <ul>
<li><a href="<?php echo e(route('list-blog')); ?>">List Blog</a></li>

</ul>
<?php echo $__env->yieldContent('content'); ?>


 </body>
 </html>



 
<?php /**PATH E:\xampp\htdocs\excelledia-app\resources\views/layout/admin.blade.php ENDPATH**/ ?>