
<?php $__env->startSection('content'); ?>
<?php

echo "welcome";

?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\excelledia-app\resources\views/dashboard.blade.php ENDPATH**/ ?>