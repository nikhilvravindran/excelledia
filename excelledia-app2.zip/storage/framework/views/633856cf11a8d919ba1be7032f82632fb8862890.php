
<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('create-blog')); ?>" method="POST">
   <?php echo csrf_field(); ?>
   <?php if($errors->any()): ?>
   <div class="alert alert-danger">
      <ul>
         <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <li><?php echo e($error); ?></li>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
   </div>
   <?php endif; ?>


   <div class="form-group">
      <label class="col-sm-2 col-sm-2 control-label">Title</label>
      <div class="col-sm-10">
         <input type="text" name="title" class="form-control">
      </div>
   </div>

   <div class="form-group">
      <label class="col-sm-2 col-sm-2 control-label">Author</label>
      <div class="col-sm-10">
         <input type="text" name="author" class="form-control" >
      </div>
   </div>

   <div class="form-group">
      <label class="col-sm-2 col-sm-2 control-label">Description</label>
      <div class="col-sm-10">
          <textarea rows="5" cols="20" class="form-control" name="description"></textarea>
      </div>
   </div>
  
   <button type="submit" class="btn btn-success btnSubmit">Save</button>
</form>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\excelledia-app\resources\views/add-blog.blade.php ENDPATH**/ ?>