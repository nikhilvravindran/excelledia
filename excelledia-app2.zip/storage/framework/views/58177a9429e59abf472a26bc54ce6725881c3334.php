<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial;
            padding: 20px;
            background: #f1f1f1;
        }


        .fakeimg {
            background-color: #aaa;
            width: 100%;
            padding: 20px;
        }

        .card {
            background-color: white;
            padding: 20px;
            margin-top: 20px;
        }

        .row:after {
            content: "";
            display: table;
            clear: both;
        }

        .comment_form ,.reply_comment_form {
            display: none;
        }
        .replies{
            margin-left: 30px;
        }

    </style>
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
</head>

<body>



    <div class="row">
        <?php if(!empty($blog)): ?>
            <div class="card">
                <h2> <?php echo e($blog->title); ?></h2>
                <h5>By <?php echo e($blog->author); ?>,Posted on <?php echo e(date('d-m-Y', strtotime($blog->created_at))); ?>

                </h5>
                <p><?php echo e($blog->description); ?></p>
                <hr />
                <h4>Display Comments</h4>
  
                 <?php echo $__env->make('comments', ['comments' => $blog->comments, 'blog_id' => $blog->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
            </div>


        <?php endif; ?>

        <hr />
        <button type="button" class="addcomment">Add Comment</button>
        <div class="comment_form">
            <form action="<?php echo e(route('add-comment')); ?>" method="post" id="comment-form">
                <?php echo csrf_field(); ?>
               
                <div class="form-group">
                    <label class="col-sm-2 col-sm-2 control-label">Name</label>
                    <div class="col-sm-10">
                        <input type="text" name="name" class="form-control" required>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 col-sm-2 control-label">Description</label>
                    <div class="col-sm-10">
                        <textarea rows="5" cols="20" class="form-control" name="comment" required></textarea>
                    </div>
                </div>
                <input type="hidden" name="blog_id" value="<?php echo e($blog->id); ?>">
                <button type="submit" class="btn btn-success btnSubmit">Post</button>
                <button type="button" class="btn btn-success btnClose">Close</button>
            </form>
        </div>
    </div>
   
    <script>
        $(".addcomment").click(function() {
            $(".comment_form").slideToggle("slow");
        });
        $(".btnClose").click(function() {
            $(".comment_form").slideToggle("hide");
        });


        $('.show_comments').on("click",".replycomment",function() {
            $(this).parent('.reply_form').find(".reply_comment_form").show();
        });
        $('.show_comments').on("click",".btnReplyClose",function() {
           $(this).parents('.reply_form').find(".reply_comment_form").hide();
        })
    
    </script>
</body>

</html>
<?php /**PATH E:\xampp\htdocs\excelledia-app\resources\views/read-blog.blade.php ENDPATH**/ ?>