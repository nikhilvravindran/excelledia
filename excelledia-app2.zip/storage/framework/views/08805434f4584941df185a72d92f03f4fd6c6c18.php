<?php if(!empty($comments)): ?>
<div class="show_comments">
   <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <div class="card_comment">
      <h4><?php echo e($comment->name); ?></h4>
      <p><?php echo e($comment->comment); ?></p>
   </div>
   <div class="reply_form"  id="<?php echo e($comment->id); ?>">
      <button type="button" id="<?php echo e($comment->id); ?>" class="replycomment">Reply</button>
      <div class="reply_comment_form">
         <form  action="<?php echo e(route('add-comment')); ?>" method="post" id="reply-comment-form-<?php echo e($comment->id); ?>">
            <?php echo csrf_field(); ?>
            <?php if($errors->any()): ?>
   <div class="alert alert-danger">
      <ul>
         <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <li><?php echo e($error); ?></li>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
   </div>
   <?php endif; ?>
            <div class="form-group">
               <label class="col-sm-2 col-sm-2 control-label">Name</label>
               <div class="col-sm-10">
                  <input type="text" name="name" class="form-control" required>
               </div>
            </div>
            <div class="form-group">
               <label class="col-sm-2 col-sm-2 control-label">Description</label>
               <div class="col-sm-10">
                  <textarea rows="5" cols="20" class="form-control" name="comment" required></textarea>
               </div>
            </div>
            <input type="hidden" name="parent_id" value="<?php echo e($comment->id); ?>">
            <input type="hidden" name="blog_id" value="<?php echo e($blog_id); ?>">
            <button type="submit" id="<?php echo e($comment->id); ?>" class="btn btn-success btnReplySubmit">Post</button>
            <button type="button" class="btn btn-success btnReplyClose">Close</button>
         </form>
      </div>
   </div>
   <div class="replies">
   <?php echo $__env->make('comments', ['comments' => $comment->replies], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>
<script></script><?php /**PATH E:\xampp\htdocs\excelledia-app\resources\views/comments.blade.php ENDPATH**/ ?>