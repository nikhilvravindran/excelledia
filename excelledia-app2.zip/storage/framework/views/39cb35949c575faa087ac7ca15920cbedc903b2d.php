
<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('add-blog')); ?>">Add Blog</a>
<table border='1' class="blog-table">

   <tr>
      <th>Title</th>
      <th>Author</th>
      <th>Actions</th>
   </tr>
   <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <tr>


      <td><?php echo e($blog->title); ?></td>
      <td><?php echo e($blog->author); ?></td>
      <td><a href="<?php echo e(route('edit-blog', ['id' => $blog->id])); ?>">Edit</a> <a class="delete-blog" data-url="<?php echo e(route('delete-blog', ['id' => $blog->id])); ?>" href="javascript:void(0)">Delete</a></td>

   </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<script type="text/javascript">

   $(document).ready(function () {

      $('.blog-table').on('click', '.delete-blog', function () {
         var url = $(this).attr('data-url');
         if (confirm('Do you want to delete.?')) {
            window.location.href = url;
         }

      })

   })

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\excelledia-app\resources\views/list-blog.blade.php ENDPATH**/ ?>