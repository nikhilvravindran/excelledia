@extends('layout.admin')
@section('content')
<?php

echo "welcome";

?>

@endsection