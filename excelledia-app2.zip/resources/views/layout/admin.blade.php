<!DOCTYPE html>
 <html>
 <head>
 	<meta charset="utf-8">
 	<title></title>
 	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
 </head>
 <body>
 <ul>
<li><a href="{{ route('list-blog') }}">List Blog</a></li>

</ul>
@yield('content')


 </body>
 </html>



 
